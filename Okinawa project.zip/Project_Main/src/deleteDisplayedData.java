import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.swing.JOptionPane;


public class deleteDisplayedData {

	
	
	
	public static void delete(String mob) {
	
		DAO db = new DAO();
        Connection conn = db.getConnection();

        try{
        	
        	long mobile_no=Long.parseLong(mob);
        	
        	String deleteQuery= "delete from personalInfo where mobile_no =?";
        	
        	PreparedStatement preparedStatement;
        	
        	preparedStatement = conn.prepareStatement(deleteQuery);
        	preparedStatement.setString(1, mob+"");
			
    	 int count = preparedStatement.executeUpdate();
    		
    	 if(count==0)		
     		   System.out.println("No Recored Found with mob= !!!"+mob);
  		else
  		   System.out.println("Total "+count + " Records Deleted !!!");
    		
        	
        }
        catch(Exception e){
        	System.out.println(e);
        }
		

	}

}
