import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;


public class DeleteData implements ActionListener {

	JFrame f;
	
	TextField tf1;
	
	JLabel l1,l2;
	
	JButton b1,b2;
	
	ImageIcon img ;
	
	static showroom showroomObj;
	
	String s ="";
	DeleteData(showroom showroomObj){
		
		this.showroomObj = showroomObj;
		
		
		f = new JFrame();
		f.setSize(300, 200);
		f.getContentPane().setBackground(Color.WHITE);
		f.setLayout(null);
		f.setLocationRelativeTo(null);
		f.setResizable(false);
		
		img = new ImageIcon("D:\\interncode\\delete.jpg");
          		
		l2 = new JLabel(img);
		l2.setBounds(0, 0, 300, 200);
		f.add(l2);
		
	    l1=	new JLabel("Enter Mobile No");
	 	l1.setBounds(20, 60, 110, 25);
	 	l1.setFont(new Font("Arial",Font.ITALIC,14));
	 	l1.setOpaque(false);
	 	//l1.setForeground(Color.WHITE);
	 	l2.add(l1);
	 	
	 	
	 	tf1 = new TextField();
	 	tf1.setBounds(140, 60, 130, 25);
	 	tf1.setBackground(null);
	 	l2.add(tf1);
		
	 	//-----------------------------------------------------------------
	 	b1 = new JButton("Delete");
	 	b1.setBounds(50, 110, 90, 25);
	 	//b1.setBackground(Color.WHITE);
	 	b1.addActionListener(this);
	 	l2.add(b1);
	 	
	 	b2 = new JButton("Cancel");
	 	b2.setBounds(160, 110, 90, 25);
	 //	b2.setOpaque(false);
	 	//b2.setContentAreaFilled(false);
	 	b2.addActionListener(this);
	 	l2.add(b2);
	 	//-----------------------------------------------------------------
		f.setVisible(true);
		
		
	}
	
	public static void main(String[] args) {
		
		showroom showroomObj = new showroom();
		DeleteData dd = new DeleteData( showroomObj);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		String s1 = tf1.getText();
		
		Object obj = e.getSource();
		
		if(obj == b2 ){
			f.dispose();
			showroomObj.showFrame(); 
		}
		else {
			
			if(s1.isEmpty()){
				JOptionPane.showMessageDialog(f,"Enter the mobile number " );
			}
			else{
				DisplayToBeDeletedData dd = new DisplayToBeDeletedData(s1,showroomObj);
				f.dispose();	
			}
		}
		
		
	}

}
