import java.awt.Color;
	import java.awt.Font;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;

	import javax.swing.ImageIcon;
	import javax.swing.JButton;
	import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;
	
public class Lite_Slider implements ActionListener {



	
		JFrame f;
		
		JLabel lb1,lb2,l3;
		
		ImageIcon i1, i2, i3, i4 , i5 ,i6,img;
		
		JButton b1;
		
		
		
		 Lite_Slider (){
			f =new JFrame();
			f.setSize(800, 600);
			f.setLocationRelativeTo(null);
			f.setLayout(null);
			f.getContentPane().setBackground(Color.WHITE);
			f.setResizable(false);
			
			img = new ImageIcon("D:\\interncode\\slider_bg.jpg");
			l3 = new JLabel(img);
			l3.setBounds(0,0,800,600);
			f.add(l3);
			
			
			lb1 = new JLabel("LITE");
			lb1.setBounds(350, 20,300, 40);
			lb1.setForeground(Color.WHITE);
			lb1.setFont(new Font("Algerian",Font.ITALIC,35));
			l3.add(lb1);
			
			i1 = new ImageIcon("D:\\interncode\\lite\\okinawa-lite specifications.jpg");
			i2 = new ImageIcon("D:\\interncode\\lite\\okinawa-lite front and rear image.jpg");
			i3 = new ImageIcon("D:\\interncode\\lite\\lite.jpg");
			i4 = new ImageIcon("D:\\interncode\\lite\\okinawa speedometer.jpg");
			i5 = new ImageIcon("D:\\interncode\\lite\\lite tail lamp.jpg");
			i6 = new ImageIcon("D:\\interncode\\lite\\lite dikki and battery.jpg");
			
			
			lb2 = new JLabel(i1);
			lb2.setBackground(Color.WHITE);
			lb2.setBounds(10, 70,770, 400);
			l3.add(lb2);
			
			
			b1 =new JButton("Close");
			b1.setBounds(330, 500, 150, 25);
			b1.setBackground(null);
			b1.addActionListener(this);
			l3.add(b1);
			
			
			f.setVisible(true);
			
			startSlideShow();
			
		
		 }
		
		 private void  startSlideShow() {
			 Timer timer = new Timer(1500, new ActionListener() {
			        int count = 0;

			        @Override
			        public void actionPerformed(ActionEvent e) {
			            switch (count % 6) {
			                case 0:
			                    lb2.setIcon(i1);
			                    break;
			                case 1:
			                    lb2.setIcon(i2);
			                    break;
			                case 2:
			                    lb2.setIcon(i3);
			                    break;
			                case 3:
			                    lb2.setIcon(i4);
			                    break;
			                case 4:
			                    lb2.setIcon(i5);
			                    break;
			                case 5:
			                    lb2.setIcon(i6);
			                    break;
			            }
			            count++;
			        }
			    });
			    timer.start();
		 }
		
		public static void main(String args[]){
			
			
			Lite_Slider lt =new  Lite_Slider();
			
		}


		public void showFrame(){
			f.setVisible(true);
		}
		
		
		@Override
		public void actionPerformed(ActionEvent e) {
			Object obj = e.getSource();
			
			if(obj == b1){
				
				f.dispose();
			}
			
		}

	


}