import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class Update_id implements ActionListener {

	JFrame f;
	
	TextField tf1;
	
	Label l1;
	
	Button b1,b2;
	
	  static showroom showroomObj;
	
	Update_id(showroom showroomObj){
		
		this.showroomObj =showroomObj; 
		
		f = new JFrame();
		f.setSize(400,200);
		f.setLocationRelativeTo(null);
		f.setResizable(false);
		f.getContentPane().setBackground(Color.WHITE);
		f.setLayout(null);
		
		//---------------------------------------------------------------------
		
		l1=new Label("Enter the id :");
		l1.setBounds(50, 50,100,25);
		l1.setFont(new Font("Arial",Font.ITALIC,15));
		f.add(l1);
				
		tf1 = new TextField();
		tf1.setBounds(150, 50, 100,25);
		f.add(tf1);
		
		//---------------------------------------------------------------------
		
		b1 = new Button("check");
		b1.setBounds(100, 100, 90, 25);
		b1.addActionListener(this);
		f.add(b1);
		
		
		b2 = new Button("cancel");
		b2.setBounds(200, 100, 90, 25);
		b2.addActionListener(this);
		f.add(b2);
		//---------------------------------------------------------------------
		
		f.setVisible(true);
		
	}
	
	
	public static void main(String[] args) {
		
		showroom showroomObj = new showroom();
		Update_id ui = new Update_id(showroomObj);

	}


	@Override
	public void actionPerformed(ActionEvent e) {
		
		Object obj = e.getSource();
		
		String s1 = tf1.getText();
		if(obj == b2){
			
			f.dispose();			
			  showroomObj.showFrame();
			
		}
		else{
		
		if(s1.isEmpty()){
			JOptionPane.showMessageDialog(f, "Enter id");
		}
		           else{
			displayDataToBeUpdated  du = new displayDataToBeUpdated(s1,showroomObj);
		               }
		
		   }
	}

}
