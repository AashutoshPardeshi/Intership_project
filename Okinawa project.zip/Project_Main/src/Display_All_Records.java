

import java.sql.*;
import java.io.*;


public class Display_All_Records {

	static String rows [][] = new String[100][9];
	
	static int row=0;
	
	public static void display() {

		DAO db = new DAO();
		Connection conn = db.getConnection();
    try{
	
    	
    	String selectQuery ="select * from personalInfo";
    	
    	PreparedStatement preparedStatement = conn.prepareStatement(selectQuery);
    	
    	ResultSet result = preparedStatement.executeQuery();
    	
    	
    	while(result.next()){
    		
    		for(int i=0; i<9; i++)
    			rows[row][i]=result.getString((i+1));
    			row++;
    		
    	}
    	ViewCustomer.populateArray(rows);
    	
      }
catch(Exception e){
	System.out.println(e);
}
		
	}
	
	public static void main(String args[]){
		Display_All_Records.display();
	}

}
