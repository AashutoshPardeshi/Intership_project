import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;



public class showroom implements ActionListener{

	JFrame f;
	
	JLabel lb1,lb2;
	
	JLabel l3;
	
	JButton b1,b2,b3,b4,b5,b6;
	
	ImageIcon i1, i2, i3, i4 , i5 ,i6,i7,i8,i9,img;
	
	static Lite_Slider lt;
	
	
	
	showroom(){
		
		f =new JFrame();
		f.setSize(1400, 715);
		f.setTitle("Okinawa Electric Scooter Dashboard");//changes
		f.setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\interncode\\oki.jpg"));//change

		f.setLocationRelativeTo(null);
		f.setLayout(null);
		f.getContentPane().setBackground(Color.black);
		//f.setResizable(false);
		
	
		
		lb1 = new JLabel(i9);
		lb1.setBounds(250, 10,300, 50);
		//lb1.setForeground(Color.RED);
		//lb1.setFont(new Font("Algerian",Font.ITALIC,30));
		f.add(lb1);
	
		
		img = new ImageIcon("D:\\interncode\\oki.jpg");
		l3 = new JLabel(img);
		l3.setBounds(100,0, 1200, 725);
		l3.setBackground(Color.gray);
		
		f.add(l3);
		
		
		
		//ImageIcon img = new ImageIcon("C:\\Users\\HP\\Desktop\\shreeshailya.jpg");
		//lb2 = new JLabel(img);
		lb2 = new JLabel(i1);
		lb2.setBackground(Color.WHITE);
		lb2.setBounds(10, 70,770, 300);
		l3.add(lb2);
		
		//------------------------------------------------------------------------------------------------
		
		b1 =new JButton("Add Enquiry");
		
		b1.setBounds(0, 100, 200, 50);
		b1.setFont(new Font("Arial", Font.BOLD, 22));
		//b1.setBorderPainted(true); 
		b1.setBackground(Color.darkGray);
		b1.setForeground(Color.WHITE);
		
		b1.addActionListener(this);
		l3.add(b1);
		
		/*b1.setBorder(BorderFactory.createCompoundBorder(
        BorderFactory.createLineBorder(Color.WHITE, 1),
        BorderFactory.createEmptyBorder(10, 20,10, 20)));*/
		
	
		b2 =new JButton("Delete");
		b2.setBounds(50, 200, 200,50);
		b2.setFont(new Font("Arial", Font.BOLD, 24));
		b2.setBackground(Color.darkGray);
		b2.setForeground(Color.WHITE);
		b2.addActionListener(this);
	    l3.add(b2);
	
		b3 =new JButton("Update");
		b3.setBounds(100, 300, 200,50);
		b3.setBackground(Color.darkGray);
		b3.setFont(new Font("Arial", Font.BOLD, 24));
		b3.setForeground(Color.WHITE);
		b3.addActionListener(this);
		l3.add(b3);
	
		b4 =new JButton("Display");
		b4.setBounds(1000, 100, 200,50);
		b4.setFont(new Font("Arial", Font.BOLD, 24));
		b4.setBackground(Color.darkGray);
		b4.setForeground(Color.WHITE);
		b4.addActionListener(this);
		l3.add(b4);
	
		b5 =new JButton("Model");
		b5.setBounds(950, 200, 200,50);
		b5.setFont(new Font("Arial", Font.BOLD, 24));
		b5.setBackground(Color.darkGray);
		b5.setForeground(Color.WHITE);
		b5.addActionListener(this);
		l3.add(b5);
		
		b6 =new JButton("Exit");
		b6.setBounds(900, 300, 200,50);
		b6.setFont(new Font("Arial", Font.BOLD, 24));
		b6.setBackground(Color.darkGray);
		b6.setForeground(Color.WHITE);
		b6.addActionListener(this);
		l3.add(b6);
	
		
		
		f.setVisible(true);
		
	}
	
	public void showFrame(){
		f.setVisible(true);
	}
	
	public static void main(String args[]){
		showroom sr = new showroom();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		Object obj = e.getSource();
		f.dispose();
		if(obj == b1){
			Enquiry_Form ef = new Enquiry_Form(this);
			
		}
		else if(obj == b2){
			DeleteData dd = new DeleteData(this);
			
		}
		else if(obj == b3){
			Update_id  uid =new Update_id (this);
			
		}
        else if(obj == b4){
			
        	Display_All_Records.display();
        
        	
		}else if(obj == b5){
			 Model model = new Model(this);
			
		}else if(obj == b6){
			f.dispose();
		}
		
	}

	
	
	
}
