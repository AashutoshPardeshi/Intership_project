import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Date;


public class UploadToDatabase {

	
	public static void Upload(String Id , String Name, String Email,String Mob,String Address ,String Budget ,String Model ,String paymentMode ,String Date) {
	
		try{
		DAO db =  new DAO();
		Connection conn = db.getConnection();
		
		int id =Integer.parseInt(Id);
		
		String name =Name;
		
		String email = Email;
		
		long mobile_no = Long.parseLong(Mob);
		
		String address =Address;
		
		String budget =Budget;
		
		String model =Model;
		
		String payment =paymentMode;
		
		String date = Date;
		
		String insertQuery ="insert into personalInfo values(?,?,?,?,?,?,?,?,?)";
		
		PreparedStatement preparedStatement;
		
		preparedStatement =conn.prepareStatement(insertQuery);
		
		preparedStatement.setString(1, id+"");
		preparedStatement.setString(2, name);
		preparedStatement.setString(3, email);
		preparedStatement.setString(4, mobile_no+"");
		preparedStatement.setString(5, address);
		preparedStatement.setString(6, budget);
		preparedStatement.setString(7, model);
		preparedStatement.setString(8, payment);
		preparedStatement.setString(9, date);
		
		preparedStatement.executeUpdate();
		
		 System.out.println("Data Uploaded Successfully  !!!");
		}
		catch(Exception e){
			System.out.println("Unable to upload data");
			System.out.println(e);
		}
		
	}

}
