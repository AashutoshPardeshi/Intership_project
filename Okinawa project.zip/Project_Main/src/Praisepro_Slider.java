import java.awt.Color;
	import java.awt.Font;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;

	import javax.swing.ImageIcon;
	import javax.swing.JButton;
	import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;
	
public class Praisepro_Slider implements ActionListener {



	
		JFrame f;
		
		JLabel lb1,lb2,l3;
		
		ImageIcon i1, i2, i3,img;
		
		JButton b1;
		
		 Praisepro_Slider (){
			f =new JFrame();
			f.setSize(800, 600);
			f.setLocationRelativeTo(null);
			f.setLayout(null);
			f.getContentPane().setBackground(Color.WHITE);
			f.setResizable(false);
			
			img = new ImageIcon("D:\\interncode\\slider_bg.jpg");
			l3 = new JLabel(img);
			l3.setBounds(0,0,800,600);
			f.add(l3);
			
			
			lb1 = new JLabel("PRAISE PRO");
			lb1.setBounds(320, 20,300, 40);
			lb1.setForeground(Color.white);
			lb1.setFont(new Font("Algerian",Font.ITALIC,30));
			l3.add(lb1);
			
			i1 = new ImageIcon("D:\\interncode\\praise pro\\Praisepro.jpg");
			i2 = new ImageIcon("D:\\interncode\\praise pro\\praise pro.jpg");
			i3 = new ImageIcon("D:\\interncode\\praise pro\\Okinawa-PraisePro-Front.jpg");
			
			
			lb2 = new JLabel(i1);
			lb2.setBackground(Color.WHITE);
			lb2.setBounds(10, 70,770, 400);
			l3.add(lb2);
			
			
			b1 =new JButton("Close");
			b1.setBounds(330, 500, 150, 25);
			b1.addActionListener(this);
			l3.add(b1);
			
			
			f.setVisible(true);
			startSlideShow();
		
		}
		 
		 public void startSlideShow(){
			 
				Timer timer = new Timer(1500,new ActionListener(){

					int count=0;

					@Override
					public void actionPerformed(ActionEvent e) {
						
						
						switch(count%4)  {
						
						case 0:	lb2.setIcon(i1);
	 					         break;
						
						case 1 :lb2.setIcon(i2);
	                             break; 
					
						case 2:lb2.setIcon(i3);
						        break;
					
						
						}	
						count++;
					}
			
				});
		       timer.start();		
				
	 		 }
			
		
		
		public static void main(String args[]){
			
			
			Praisepro_Slider ps =new  Praisepro_Slider();
			
		}



		@Override
		public void actionPerformed(ActionEvent e) {
			Object obj = e.getSource();
			
			if(obj == b1){
				
				f.dispose();
			}
			
		}

	


}