import java.awt.Button;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;


public class Model implements ActionListener {
	JFrame f;
	JButton b1,b2,b3,b4,b5,b6,b7,b8,b9;

	
	JLabel l1;
	ImageIcon img;
	
	static showroom showroomObj;
	
	
	Model(showroom showroomObj){
		
		this.showroomObj = showroomObj;
	
		
        f =  new JFrame();
		f.setSize(500, 400);
        f.setLocationRelativeTo(null);
		f.setLayout(null);
		
	//----------------------------------------------------------------------------------------------------------	
		
		img = new ImageIcon("D:\\interncode\\okinawa-galaxy-store.jpeg");
		
		l1 = new JLabel(img);
		l1.setBounds(0, 0,500, 400);
		f.add(l1);
	
		//----------------------------------------------------------------------------------------------------------	
		b1 = new JButton("OHKI-90");
		b1.setForeground(Color.white);
		b1.setBounds(80, 70, 120, 30);
		b1.addActionListener(this);
		b1.setContentAreaFilled(false);
		l1.add(b1);
		
		b1.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(Color.WHITE, 2), 
                BorderFactory.createEmptyBorder(10, 20, 10, 20) ));
		
		
	
		
		//----------------------------------------------------------------------------------------------------------	
		b2 = new JButton("IPRAISE-PLUS");
		b2.setForeground(Color.white);
		b2.setBounds(220, 70, 130, 30);
		b2.addActionListener(this);
		b2.setContentAreaFilled(false);
		l1.add(b2);
		
		b2.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(Color.WHITE, 2), 
                BorderFactory.createEmptyBorder(10, 20, 10, 20) ));
		
	
		//----------------------------------------------------------------------------------------------------------	
		b3 = new JButton("PRAISE PRO");
		b3.setForeground(Color.white);
		b3.setBounds(80, 120, 120, 30);
		b3.addActionListener(this);
		b3.setContentAreaFilled(false);
		l1.add(b3);
		
		b3.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(Color.WHITE, 2), 
                BorderFactory.createEmptyBorder(10, 20, 10, 20) ));
		
		
		//----------------------------------------------------------------------------------------------------------	
	
		
		b4 = new JButton("RIDGE +");
		b4.setForeground(Color.white);
		b4.setBounds(220, 120, 120, 30);
		b4.addActionListener(this);
		b4.setContentAreaFilled(false);
		l1.add(b4);
		
		b4.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(Color.WHITE, 2), 
                BorderFactory.createEmptyBorder(10, 20, 10, 20) ));
		//----------------------------------------------------------------------------------------------------------	

		
		b5 = new JButton("RIDGE 100");
		b5.setForeground(Color.white);
		b5.setBounds(80, 170, 120, 30);
		b5.addActionListener(this);
		b5.setContentAreaFilled(false);
		l1.add(b5);
		
		b5.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(Color.WHITE, 2), 
                BorderFactory.createEmptyBorder(10, 20, 10, 20) ));
		
		
			
		//----------------------------------------------------------------------------------------------------------	
		b6 = new JButton("DUAL 100");
		b6.setForeground(Color.white);
		b6.setBounds(220, 170, 120, 30);
		b6.addActionListener(this);
		b6.setContentAreaFilled(false);
		l1.add(b6);
		
		b6.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(Color.WHITE, 2), 
                BorderFactory.createEmptyBorder(10, 20, 10, 20) ));
		
		
		//----------------------------------------------------------------------------------------------------------	
		b7 = new JButton("R30");
		b7.setForeground(Color.white);
		b7.setBounds(80, 220, 120, 30);
		b7.addActionListener(this);
		b7.setContentAreaFilled(false);
		l1.add(b7);
		
		b7.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(Color.WHITE, 2), 
                BorderFactory.createEmptyBorder(10, 20, 10, 20) ));
		
		
		//----------------------------------------------------------------------------------------------------------	
		b8 = new JButton("LITE");
		b8.setForeground(Color.white);
		b8.setBounds(220, 220, 120, 30);
		b8.addActionListener(this);
		b8.setContentAreaFilled(false);
		l1.add(b8);
		
		b8.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(Color.WHITE, 2), 
                BorderFactory.createEmptyBorder(10, 20, 10, 20) ));
		
		
		//----------------------------------------------------------------------------------------------------------	
		
		
		b9 = new JButton("CANCEL");
		b9.setForeground(Color.white);
		b9.setBounds(150, 270, 120, 30);
		b9.addActionListener(this);
		b9.setContentAreaFilled(false);
		l1.add(b9);
		
		b9.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(Color.WHITE, 2), 
                BorderFactory.createEmptyBorder(10, 20, 10, 20) ));
		
		
		//----------------------------------------------------------------------------------------------------------	
		
		
		f.setVisible(true);

}

	@Override
	public void actionPerformed(ActionEvent e) {
	
              Object obj =e.getSource();
		
              if(obj == b1){
            	  okhi90_Slider oo=new okhi90_Slider();
              }
              else if(obj ==b2){
            	  iPraiseplus_Slider ipp =new  iPraiseplus_Slider();
              }
              else if(obj ==b3){
            	  Praisepro_Slider ps = new Praisepro_Slider();
              }
              else if(obj ==b4){
            		Rigdeplus_Slider rp =new  Rigdeplus_Slider();
              }
              else if(obj == b5){

      			Rigde100_Slider rd =new  Rigde100_Slider();
              }
              else if(obj == b6){
            	  Dual100_Slider dl =new  Dual100_Slider();
              }
              else if(obj ==b7){
            		
      			R30_Slider rr =new  R30_Slider();
              }
              else if(obj == b8){
            	  Lite_Slider lt =new  Lite_Slider();
            	 
              }
              else if(obj == b9){
            	  f.dispose();
            	  showroomObj.showFrame();
              }
		
	}
}
