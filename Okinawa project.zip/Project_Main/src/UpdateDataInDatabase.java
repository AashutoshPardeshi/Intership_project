import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;


public class UpdateDataInDatabase  {

	static JProgressBar jpb1;
	
	static Thread progressBarThread;
	
	public static  void update(String Id ,String Name,String Email ,String Mob, String Address,String Budget ,String Model , String Payment,String Date  ) {
		try{
		DAO db = new DAO();
		Connection conn = db.getConnection();

	   int id = Integer.parseInt(Id);
	   String name = Name;
	   String email = Email;
	   long mobile_no=Long.parseLong(Mob);
	   String address =Address;
	   String budget =Budget;
	   String model =Model;
	   String payment =Payment;
	   String date =Date;
	   
	   String updateQuery ="update personalInfo set name=?,email =? ,mobile_no=? ,address =? ,budget=?,model=?,payment=?,date=? where id=?";
		
	   PreparedStatement preparedStatement;
	   
	   preparedStatement = conn.prepareStatement(updateQuery);
	   
	   
	   preparedStatement.setString(1, name);
	   preparedStatement.setString(2, email);
	   preparedStatement.setLong(3,mobile_no);
	   preparedStatement.setString(4,address);
	   preparedStatement.setString(5, budget);
	   preparedStatement.setString(6, model);
	   preparedStatement.setString(7, payment);
	   preparedStatement.setString(8, date);
	   preparedStatement.setInt(9, id);
	   int rowsAffected = preparedStatement.executeUpdate();

       if (rowsAffected > 0) {
    		   
           JOptionPane.showMessageDialog(null, "Data updated successfully.");
       } else {
           JOptionPane.showMessageDialog(null, "Failed to update data.");
       }
	   
		}
		catch(Exception e){
			System.out.println(e);
		}
		
	}
	

}
