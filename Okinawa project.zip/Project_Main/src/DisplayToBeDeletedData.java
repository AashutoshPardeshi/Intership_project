import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;


public class DisplayToBeDeletedData implements ActionListener {

	static JFrame f;

	JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9,l10;

	static TextField tf1, tf2, tf3, tf4, tf5, tf6;

	static JRadioButton rb1, rb2, rb3, rb4, rb5, rb6, rb7, rb8;

	JComboBox cb1;
	
	Button b1, b2;
	
	  boolean recordFound = false; 
	  static String Id = "", Name = "", Email = "", Mob_no = "", Address = "",
				Budget = "", Model = "", Payment = "", Date = "";  
	  
	  String mob;
		
		static showroom showroomObj;
		
		
		ImageIcon img;
		
	 DisplayToBeDeletedData(String mob,showroom showroomObj) {

		 this.mob=mob;
		 
         this.showroomObj = showroomObj;
		 
			f = new JFrame();
			f.setSize(500, 750);
			f.setLocationRelativeTo(null);
			f.setResizable(false);
			f.setLayout(null);

			
			img = new ImageIcon("D:\\interncode\\computer-keyboard-key-delete-business-concept-GXEFJG.jpg");
			l10 = new JLabel(img);
			l10.setBounds(0,0, 500, 750);
			f.add(l10);

	     // ------------------------------------------------------------------
			l1 = new JLabel("Id :");
			l1.setFont(new Font("Arial", Font.BOLD, 15));
			//l1.setForeground(Color.WHITE);
			l1.setBounds(50, 80, 60, 25);
			l10.add(l1);

			tf1 = new TextField();
			tf1.setBounds(130, 80, 250, 25);
			//tf1.setBackground(null);
			tf1.setText(Id);
			l10.add(tf1);

			// -------------------------------------------------------------------

			l2 = new JLabel("Name :");
			l2.setFont(new Font("Arial", Font.BOLD, 15));
		//	l2.setForeground(Color.WHITE);
			l2.setBounds(50, 120, 60, 25);
			l10.add(l2);

			tf2 = new TextField();
			tf2.setBounds(130, 120, 250, 25);
			///tf2.setBackground(null);
			l10.add(tf2);

			// -------------------------------------------------------------------

			l3 = new JLabel("Email :");
			l3.setFont(new Font("Arial", Font.BOLD, 15));
		//	l3.setForeground(Color.WHITE);
			l3.setBounds(50, 160, 60, 25);
			l10.add(l3);

			tf3 = new TextField();
			tf3.setBounds(130, 160, 250, 25);
			//tf3.setBackground(null);
			l10.add(tf3);

			String s1[] = { "@gmail.com", "@yahoo.com", "@rediffmail.com",
					"@outlook.com", "@msn.co.in" };
			cb1 = new JComboBox(s1);
			cb1.setBounds(390, 160, 100, 25);
			//cb1.setBackground(null);
			l10.add(cb1);

			// -------------------------------------------------------------------

			l4 = new JLabel("Mob :");
			l4.setFont(new Font("Arial", Font.BOLD, 15));
			//l4.setForeground(Color.WHITE);
			l4.setBounds(50, 200, 60, 25);
			l10.add(l4);

			tf4 = new TextField();
			tf4.setBounds(130, 200, 250, 25);
			//tf4.setBackground(null);
			l10.add(tf4);

			// -------------------------------------------------------------------

			l5 = new JLabel("Address :");
			l5.setFont(new Font("Arial", Font.BOLD, 15));
			//l5.setForeground(Color.WHITE);
			l5.setBounds(50, 240, 80, 25);
			l10.add(l5);

			tf5 = new TextField();
			tf5.setBounds(130, 240, 250, 25);
			//tf5.setBackground(null);
			l10.add(tf5);

			// -------------------------------------------------------------------

			l6 = new JLabel("Budget :");
			l6.setFont(new Font("Arial", Font.BOLD, 15));
			//l6.setForeground(Color.WHITE);
			l6.setBounds(50, 290, 80, 25);
			l10.add(l6);

			rb1 = new JRadioButton("50k - 80k");
			rb1.setBounds(140, 290, 150, 25);
			rb1.setFont(new Font("Arial", Font.BOLD, 14));
		//	rb1.setForeground(Color.WHITE);
			rb1.setOpaque(false);
			l10.add(rb1);

			rb2 = new JRadioButton("80k  - 1 lac");
			rb2.setBounds(140, 330, 150, 25);
			rb2.setFont(new Font("Arial", Font.BOLD, 14));
			//rb2.setForeground(Color.WHITE);
			rb2.setOpaque(false);
			l10.add(rb2);

			rb3 = new JRadioButton("above lac");
			rb3.setBounds(140, 370, 150, 25);
			rb3.setFont(new Font("Arial", Font.BOLD, 14));
		//	rb3.setForeground(Color.WHITE);
			//rb3.setOpaque(false);
			l10.add(rb3);

			// -------------------------------------------------------------------

			l7 = new JLabel("Model :");
			l7.setFont(new Font("Arial", Font.BOLD, 15));
			//l7.setForeground(Color.WHITE);
			l7.setBounds(50, 410, 80, 25);
			l10.add(l7);

			rb4 = new JRadioButton("Low Speed");
			rb4.setBounds(140, 410, 150, 25);
			rb4.setFont(new Font("Arial", Font.BOLD, 14));
			//rb4.setForeground(Color.WHITE);
			rb4.setOpaque(false);
			l10.add(rb4);

			rb5 = new JRadioButton("High Speed");
			rb5.setBounds(140, 450, 150, 25);
			rb5.setFont(new Font("Arial", Font.BOLD, 14));
			//rb5.setForeground(Color.WHITE);
			rb5.setOpaque(false);
			l10.add(rb5);

			// -------------------------------------------------------------------

			l8 = new JLabel("Payment :");
			l8.setFont(new Font("Arial", Font.BOLD, 15));
			//l8.setForeground(Color.WHITE);
			l8.setBounds(50, 490, 80, 25);
			l10.add(l8);

			rb6 = new JRadioButton("Cash");
			rb6.setBounds(140, 490, 150, 25);
			rb6.setFont(new Font("Arial", Font.BOLD, 14));
			//rb6.setForeground(Color.WHITE);
			rb6.setOpaque(false);
			l10.add(rb6);

			rb7 = new JRadioButton("Loan");
			rb7.setBounds(140, 530, 150, 25);
			rb7.setFont(new Font("Arial", Font.BOLD, 14));
			//rb7.setForeground(Color.WHITE);
			rb7.setOpaque(false);
			l10.add(rb7);

			rb8 = new JRadioButton("Online");
			rb8.setBounds(140, 570, 150, 25);
			rb8.setFont(new Font("Arial", Font.BOLD, 14));
			//rb8.setForeground(Color.WHITE);
			rb8.setOpaque(false);
			l10.add(rb8);

			// -------------------------------------------------------------------

			l9 = new JLabel("Date Visit :");
			//l9.setForeground(Color.WHITE);
			l9.setFont(new Font("Arial", Font.BOLD, 15));
			l9.setBounds(50, 610, 100, 25);
			l10.add(l9);

			tf6 = new TextField();
			tf6.setBounds(140, 610, 200, 25);
			//tf6.setBackground(null);
			l10.add(tf6);

			// -------------------------------------------------------------------


	        b1 = new Button("Delete");
	        b1.setBounds(130, 670, 100, 25);
			//b1.setBackground(Color.white);
			b1.addActionListener(this);
			l10.add(b1);


	        b2 = new Button("Cancel");
	        b2.setBounds(260, 670, 100, 25);
	        //b2.setBackground(Color.white);
	        b2.addActionListener(this);
			l10.add(b2);

			// -------------------------------------------------------------------

			ButtonGroup budgetButtonGroup = new ButtonGroup();
			budgetButtonGroup.add(rb1);
			budgetButtonGroup.add(rb2);
			budgetButtonGroup.add(rb3);
			

			ButtonGroup modelButtonGroup = new ButtonGroup();
			modelButtonGroup.add(rb4);
			modelButtonGroup.add(rb5);
			
			ButtonGroup paymentButtonGroup = new ButtonGroup();
			paymentButtonGroup.add(rb6);
			paymentButtonGroup.add(rb7);
			paymentButtonGroup.add(rb8);
			
	     // -------------------------------------------------------------------

			Display(mob ); 
			
			
			 if (recordFound) {
			        f.setVisible(true);
			    } else {
			        f.dispose();
			    }
	    }

	 
	    public void Display(String mob ) {
	        DAO db = new DAO();
	        Connection conn = db.getConnection();

	        try {
	            long mobile_no = Long.parseLong(mob);

	            String selectQuery = "select * from personalInfo where mobile_no=?";
	            PreparedStatement preparedStatement = conn.prepareStatement(selectQuery);

	            preparedStatement.setLong(1, mobile_no);

	            ResultSet resultSet = preparedStatement.executeQuery();

	            while (resultSet.next()) {
					recordFound = true;
					Id = resultSet.getString(1);
					Name = resultSet.getString(2);
					Email = resultSet.getString(3);
					Mob_no = resultSet.getString(4);
					Address = resultSet.getString(5);
					Budget = resultSet.getString(6);
					Model = resultSet.getString(7);
					Payment = resultSet.getString(8);
					Date = resultSet.getString(9);

				}
	            tf1.setText(Id);
				tf2.setText(Name);
				tf3.setText(Email);
				tf4.setText(Mob_no);
				tf5.setText(Address);
				
				
				

				setSelectedRadioButton(rb1, Budget,"50k - 80k");
				setSelectedRadioButton(rb2, Budget,"80k - 1 lac");
				setSelectedRadioButton(rb3, Budget, "above lac");

				setSelectedRadioButton(rb4, Model, "Low Speed");
				setSelectedRadioButton(rb5, Model, "High Speed");

				setSelectedRadioButton(rb6, Payment,"Cash");
				setSelectedRadioButton(rb7, Payment, "Loan");
				setSelectedRadioButton(rb8, Payment, "Online");

				tf6.setText(Date);

			/*	System.out.println("Budget from database: " + Budget);
				System.out.println("Model from database: " + Model);
				System.out.println("Payment from database: " + Payment);
				*/
	            if (!recordFound) {
	            	JOptionPane.showMessageDialog(f, "No records found for the given mobile number.");
	            	
	                //ta.setText("No records found for the given mobile number.");
	            }
	        }
	        catch (Exception e) {
	            System.out.println(e);
	        }
	    }

	    private static void setSelectedRadioButton(JRadioButton radioButton,
				String valueFromDatabase, String radioButtonValue) {
			if (valueFromDatabase.equals(radioButtonValue)) {
				radioButton.setSelected(true);
			}
		}
	    
	    @Override
	    public void actionPerformed(ActionEvent e) {
	        Object obj = e.getSource();
	        
	       
	        
	        if (obj == b2) {
	            f.dispose();
	            showroomObj.showFrame();
	        }
	      
	       else if(obj == b1) {
	    	   int value =JOptionPane.showConfirmDialog(f, "Are you sure you want to delete record ","Confirm message",JOptionPane.YES_NO_OPTION);
	       
	           if(value == 0){
	        	   deleteDisplayedData.delete(mob);
	        	   f.dispose();
	        	   showroomObj.showFrame();
	           }
	           else{
	        	   f.dispose();
	           }
	    	   
	       }
	    
	    }
	    
	    

}
